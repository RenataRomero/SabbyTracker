package com.example.muertedecuna.beans;

public class Utils {

    public static final String RIOT_KEY = "RGAPI-0690d111-587f-4bd0-8cb5-8656445d82e3";
}