package com.example.muertedecuna.tools;

public class Commons {
    public static final int PAGES = 3;
    public static final int IDX_SECTION1 = 0;
    public static final int IDX_SECTION2 = 1;
    public static final int IDX_SECTION3 = 2;
}